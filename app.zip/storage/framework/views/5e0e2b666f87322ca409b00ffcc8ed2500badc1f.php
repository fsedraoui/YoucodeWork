<?php $page="freelancer-dashboard";?>

<?php $__env->startSection('content'); ?>		

<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-xl-3 col-md-4 theiaStickySidebar">
							<div class="settings-widget">
								<div class="settings-header d-sm-flex flex-row flex-wrap text-center text-sm-start align-items-center">
									<a href="freelancer-profile"><img alt="profile image" src="assets/img/img-04.jpg" class="avatar-lg rounded-circle"></a>
									<div class="ms-sm-3 ms-md-0 ms-lg-3 mt-2 mt-sm-0 mt-md-2 mt-lg-0">
										<?php if(Auth::user()->role==1): ?>
										<p class="mb-2">Bienvenu</p>
										<h3 class="mb-0"><a href="freelancer-profile"><?php echo e(Auth::user()->lastName); ?> <?php echo e(Auth::user()->firstName); ?></a></h3>
										<?php endif; ?>
										<?php if(Auth::user()->role==2): ?>
										<p class="mb-2">Bienvenu Staff <?php echo e(Auth::user()->lastName); ?> </p>
										<p class="mb-2">Vous consultez le profile de </p>
										<p class="mb-0"><a href="freelancer-profile"><?php echo e($student->lastName); ?> <?php echo e($student->firstName); ?></a></p>
										<?php endif; ?>
									</div>
									
				
								</div>
								<div class="settings-menu">
									<ul>
										<li class="nav-item">
											<a href="dashboard" class="nav-link active">
												<i class="material-icons">verified_user</i> Tableau de bord
											</a>
										</li>
										
										<li class="nav-item">
											<a href="apprenant-projetsvalides" class="nav-link">
												
												<?php if(Auth::user()->role==1): ?>
												<i class="material-icons">record_voice_over</i> Mes projets
												<?php endif; ?>
										<?php if(Auth::user()->role==2): ?>
										<i class="material-icons">record_voice_over</i> ses projets
										<?php endif; ?>
											</a>
										</li>
										<li class="nav-item">
											<a href="projects" class="nav-link">
												<i class="material-icons">local_play</i> Explorer des Projets
											</a>
										</li>
										<?php if(Auth::user()->role==1): ?>
										<li class="nav-item">
											<a href="view-jobs" class="nav-link">
												<i class="material-icons">business_center</i> Postulez pour une offre
											</a>
										</li>
										
										
										
										<li class="nav-item">
											<a href="#" class="nav-link">
												<i class="material-icons">settings</i>  Settings
											</a>
										</li>
										<li class="nav-item">
											<a href="index" class="nav-link">
												<i class="material-icons">power_settings_new</i> Logout
											</a>
										</li>
										<?php endif; ?>
									</ul>
								</div>
							</div>					
						</div>	
						
						<div class="col-xl-9 col-md-8">
							
							<div class="dashboard-sec">
								<div class="row">
									<div class="col-md-6 col-lg-4">
										<div class="dash-widget">
											<div class="dash-info">
												<div class="dash-widget-info">Projets en instance</div>
												<div class="dash-widget-count"><?php echo e($student-> projetInstanceCount); ?></div>
											</div>
											<div class="dash-widget-more">
												<a href="projetsenInstance" class="d-flex">Voir Détails <i class="fas fa-arrow-right ms-auto"></i></a>
											</div>
										</div>
									</div>
									<div class="col-md-6 col-lg-4">
										<div class="dash-widget">
											<div class="dash-info">
												<div class="dash-widget-info">Projets validés</div>
												<div class="dash-widget-count"><?php echo e($student-> projetValideCount); ?> </div>
											</div>
											<div class="dash-widget-more">
												<a href="apprenant-projetsvalides" class="d-flex">Voir Détails <i class="fas fa-arrow-right ms-auto"></i></a>
											</div>
										</div>
									</div>
									<div class="col-md-6 col-lg-4">
										<div class="dash-widget">
											<div class="dash-info">
												<div class="dash-widget-info">Tous mes projets</div>
												<div class="dash-widget-count"><?php echo e($student->projects()->count()); ?></div>
											</div>
											<div class="dash-widget-more">
												<a href="apprenant-projetsvalides" class="d-flex">Voir Détails <i class="fas fa-arrow-right ms-auto"></i></a>
											</div>
										</div>
									</div>
								</div>
								
								<!-- Chart Content -->
								<div class="row">
									<div class="col-xl-8 d-flex">
										<div class="flex-fill card">
											<div class="pro-head b-0">	
												<h5 class="card-title mb-0">Technologies</h5> 
												

											</div>
											<div class="pro-body">									
												<div id="chartradial"></div>
												<div style="    flex-wrap: wrap !important;">
													<?php $technologies = $technology_color_array ?>
												<?php if(count($technology_color_array)>0 ): ?>
													<?php $__currentLoopData = $technology_color_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													
													 <span style="margin-left: 4%;"><i class="fas fa-circle text-<?php echo e($technology[2]); ?> me-1"></i> <?php echo e($technology[0]); ?></span> (<span class="sta-count"><?php echo e($technology[1]); ?></span>)
													
													
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php else: ?>
														<p>Aucune Technologie</p>
														<?php endif; ?>	
														
												</div>
											</div>
										</div>

										



									</div>
									<div class="col-xl-4 d-flex">
										<div class="card flex-fill">
											<div class="pro-head">	
												<h5 class="card-title mb-0"><i class="fas fa-tags"></i> Tags & Outils</h5> 
												<div class="month-detail">	
													
												</div>
											</div>
											
											<div class="tags" style="padding: 5%">
												<?php if(count($allTags) > 0 ): ?>
												<?php $__currentLoopData = $allTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
														<label class="btn btn-rounded btn-sm btn-light" style="border-color: #3488da  !important; color: #3488da !important;"><?php echo e($tag); ?></label>
														
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
														<p>Aucun tag</p>
														<?php endif; ?>		
												</div>
										</div>
									</div>
								</div>
								<!-- /Chart Content -->
								
								
								
								
								
							</div>								
						</div>								
					</div>					
				</div>
			</div>				
			<!-- /Page Content -->


        </div>
		<!-- /Main Wrapper -->
		<script>
			var technologies = <?php echo json_encode($technologies, 15, 512) ?>;

		</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\YcodeWork\app\resources\views/dashboard.blade.php ENDPATH**/ ?>