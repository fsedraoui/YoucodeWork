<?php $page="blog-grid";?>

<?php $__env->startSection('content'); ?>		


<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container">
					<div class="row align-items-center inner-banner">
						<div class="col-md-12 col-12 text-center">
							<h5 class="breadcrumb-title">Découvrir les compètences de nos apprenats via leurs réalisations et projets </h5>
						<div class="search">
							<div>
							<span>
										<i class="fa fa-filter"></i> 
										
										<a href="<?php echo e(route('projects')); ?>" class="btn btn-rounded btn-sm btn-warning"><i class="fas fa-minus"></i> </a>
											<?php $__currentLoopData = $allTechnologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<a href="<?php echo e(route('projects-by-technology', $technology)); ?>" class="btn btn-rounded btn-sm btn-light"><?php echo e(strtoupper($technology)); ?></a>
											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


										</span>
									</div>
										<div>
										<form action="<?php echo e(route('projects')); ?>" method='POST'>
											<?php echo csrf_field(); ?>
											<div class="inputSearch">
											<input class="form-control form-control-sm"  type="text" name="keyword" style=" margin-right: 5%;" />
											<input class="btn btn-rounded btn-sm btn-warning" type="submit" value="Search"/>
											</div>
										</form>
									</div>
						</div>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container">
				
					<div class="row">
						<div class="col-lg-12 col-md-12">
						
							<div class="row blog-grid-row">
								<?php if($projects->count()): ?>
       						     <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
									<div class="col-md-4 col-sm-12">
								
								<!-- Blog Post -->
								<div class="blog grid-blog">
									<div class="blog-image">
										<a href="<?php echo e(route('project-details', $project->id)); ?>"><img class="img-fluid" src=" <?php echo e($project->lienImage1); ?>" alt="Post Image"></a>
									
										
									</div>
									<div class="blog-content">
										<ul class="entry-meta meta-item">
											
												
													<div class="card-body">
														<div class="avatar-group">
															<?php $__currentLoopData = $project->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<div class="avatar" style="a:hover { color: red; }" alt="<?php echo e($student->firstName); ?>">
																	<img class="avatar-img rounded-circle border border-white"  src="../assets_admin/img/profiles/avatar-02.jpg"/>
																	<div style="font-size: 7px;"><?php echo e($student->firstName); ?></div>
																</div>																										
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
														</div>	
													
												
											
											<li><i class="far fa-clock"></i> 
											<?php echo e($project->created_at->format('d-m-Y')); ?>

											</li>
										</ul>
										<h3 class="blog-title"><a href="<?php echo e(route('project-details', $project->id)); ?>"><?php echo e($project->name); ?></a></h3>
										<p class="mb-0"><?php echo nl2br($project->excerpt(100)); ?></p>

										<span class="d-block m-2">
											<i class="fa-solid fa-laptop-mobile"></i>
											<?php $__currentLoopData = $project->technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<label class="btn btn-rounded btn-sm btn-info tag" style="border-color: #ffffff; !important"><?php echo e($technology); ?></label>
											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


										</span>

										<span>
										<i class="fa fa-tag"></i> 
											<?php $__currentLoopData = $project->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<label class="btn btn-rounded btn-sm btn-light"><?php echo e($tag); ?></label>
											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


										</span>

										
										
									</div>
								</div>
								<!-- /Blog Post -->
								
							</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									<?php else: ?>
									<p>There are no posts</p>
									<?php endif; ?>
								</div>
								
							<!-- Blog Pagination -->
							

							<div class="row">
								<div class="col-md-12">
									<ul class="paginations list-pagination">
										<li><a 	
											<?php if($projects->currentPage() != 1): ?>
												href=<?php echo e(route('projects', ['page' => 1])); ?>

											<?php endif; ?>
										><i class="fas fa-angle-left"></i></a></li>
										<?php for($i=1;$i< ($projects->total()/$projects->perPage())+1 ;$i++): ?>
											<li><a 
											<?php if($i ==  $projects->currentPage()): ?>
												class="active"
											<?php else: ?> 
												href=<?php echo e(route('projects', ['page' => $i])); ?>

											<?php endif; ?>
											><?php echo e($i); ?></a></li>

										<?php endfor; ?>
										<li><a 
											<?php if($projects->currentPage() != $projects->lastPage()): ?>
												href=<?php echo e(route('projects', ['page' => $projects->lastPage()])); ?>

											<?php endif; ?>
										> <i class="fas fa-angle-right"></i></a></li>
									</ul>
								</div>
							</div>

							<!-- /Blog Pagination -->
							
						</div>
						
						<!-- Blog Sidebar -->
						<!--
						<div class="col-lg-4 col-md-12 sidebar-right theiaStickySidebar">

							
							<div class=" pro-post widget-box post-widget">
								<h4 class="pro-title">Latest Posts</h4>
								<div class="pro-content pt-0">
									<ul class="latest-posts">
										<li>
											<div class="post-thumb">
												<a href="blog-details">
													<img class="img-fluid" src="assets/img/blog/blog-thumb-03.jpg" alt="">
												</a>
											</div>
											<div class="post-info">
												<h4>
													<a href="blog-details">Kofejob - How to get job through online?</a>
												</h4>
												<a href="#" class="posts-date"><i class="far fa-calendar-alt"></i> 2 May 2021</a>
											</div>
										</li>
										<li>
											<div class="post-thumb">
												<a href="blog-details">
													<img class="img-fluid" src="assets/img/blog/blog-thumb-02.jpg" alt="">
												</a>
											</div>
											<div class="post-info">
												<h4>
													<a href="blog-details">People who completed NAND technology got job 90% </a>
												</h4>
												<a href="#" class="posts-date"><i class="far fa-calendar-alt"></i> 3 May 2021</a>
											</div>
										</li>
										<li>
											<div class="post-thumb">
												<a href="blog-details">
													<img class="img-fluid" src="assets/img/blog/blog-thumb-01.jpg" alt="">
												</a>
											</div>
											<div class="post-info">
												<h4>
													<a href="blog-details">There are many variations of passages</a>
												</h4>
												<a href="#" class="posts-date"><i class="far fa-calendar-alt"></i> 4 May 2021</a>
											</div>
										</li>
									</ul>
								</div>
							</div>
						
							<div class=" pro-post widget-box category-widget">
								<h4 class="pro-title">Blog Categories</h4>
								<div class="pro-content">
									<ul class="category-link">
										<li><a href="#">Web Development</a></li>
										<li><a href="#">IT Consultancy</a></li>
										<li><a href="#">Email Marketing</a></li>
										<li><a href="#">Business Consulting</a></li>
										<li><a href="#">Apps Development</a></li>
										<li><a href="#">SEO Optimizations</a></li>
									</ul>
								</div>
							</div>
							
							<div class=" pro-post widget-box tags-widget">
								<h4 class="pro-title">Tags</h4>
								<div class="pro-content">
									<ul class="tags">
										<li><a href="#" class="tag">Employer</a></li>
										<li><a href="#" class="tag">Student</a></li>
										<li><a href="#" class="tag">Freelancer</a></li>
										<li><a href="#" class="tag">Designer</a></li>
										<li><a href="#" class="tag">Jobs</a></li>
										<li><a href="#" class="tag">Developer</a></li>
										<li><a href="#" class="tag">Coding</a></li>
										<li><a href="#" class="tag">Skills</a></li>
										<li><a href="#" class="tag">Knowledge</a></li>
										<li><a href="#" class="tag">Node Js</a></li>
										<li><a href="#" class="tag">Courses</a></li>
										<li><a href="#" class="tag">Engineer</a></li>
										<li><a href="#" class="tag">Online</a></li>
										<li><a href="#" class="tag">Study</a></li>
										<li><a href="#" class="tag">Project</a></li>
										<li><a href="#" class="tag">Experience</a></li>
										<li><a href="#" class="tag">Freshers</a></li>
									</ul>
								</div>
							</div>
								
							<div class="pro-post widget-box post-widget">
								<h3 class="pro-title">Share</h3>
								<div class="pro-content">
									<a href="#" class="share-icon"><i class="fas fa-share-alt"></i> Share</a>
								</div>
							</div>
						
							
						</div> 
						-->
						<!-- /Blog Sidebar -->
						
					</div>
				</div>
			</div>	
			<!-- /Page Content -->


        </div>
		<!-- /Main Wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\YcodeWork\app\resources\views/blog-grid.blade.php ENDPATH**/ ?>