<?php $page="projects";?>

<?php $__env->startSection('content'); ?>
	<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Projets à traiter</h3>
								<div class="col-auto">
									
								</div>
							</div>
							
						</div>
					</div>
					<!-- /Page Header -->

					<!-- Search Filter -->
					<div class="card filter-card" id="filter_inputs">
						<div class="card-body pb-0">
							<form action="#" method="post">
								<div class="row filter-row">
									<div class="col-sm-6 col-md-3">
										<div class="form-group">
											<label>Titre du Projet</label>
											<input class="form-control" type="text">
										</div>
									</div>
									<div class="col-sm-6 col-md-3">
										<div class="form-group">
											<label>Date de création</label>
											<div class="cal-icon">
												<input class="form-control datetimepicker" type="text">
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-md-3">
										<div class="form-group">
											<label>Date dernière modification</label>
											<div class="cal-icon">
												<input class="form-control datetimepicker" type="text">
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-md-3">
										<div class="form-group">
											<button class="btn btn-primary btn-block" type="submit">Submit</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
					<!-- /Search Filter -->

					<div class="card bg-white projects-card">
						<div class="card-body pt-0">
							<div class="card-header">
								<h5 class="card-title">Projets détails</h5>
							</div>
							<div class="reviews-menu-links">
								<ul role="tablist" class="nav nav-pills card-header-pills nav-justified">
									<li class="nav-item">
										<a href="#tab-4" data-bs-toggle="tab" class="nav-link active">Tous </a>
									</li>
									<li class="nav-item">
										<a href="#tab-5" data-bs-toggle="tab" class="nav-link">Validés </a>
									</li>
									<li class="nav-item">
										<a href="#tab-6" data-bs-toggle="tab" class="nav-link"> En instance 
										</a>
									</li>
								</ul>
							</div>
							<div class="tab-content pt-0">
								<div role="tabpanel" id="tab-4" class="tab-pane fade active show">
									<div class="table-responsive">
										<table class="table table-center table-hover mb-0 datatable">
											<thead>
												<tr>
													
													<!-- <th>Avatar</th> -->
													<th>Titre</th>	
													<th>Date de création</th>	
													<th>Date de Modification</th>	
													<th>GitHub</th>	
													<th>Collaborateurs</th>	
													<th>Status</th>	
													<th class="text-end">Actions</th>
												</tr>
											</thead>
											<tbody>
											<?php $__currentLoopData = $instructor->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													
													<!-- <td>
														<h2 class="table-avatar">
															<a href="profile"><img class="me-2" src="../assets_admin/img/company/img-1.png" alt="User Image"></a>
														</h2>
													</td> -->
													
													<td><?php echo e(\Illuminate\Support\Str::limit($project->name , 15, $end='...')); ?></td>
													<td>
													<?php echo e(\Carbon\Carbon::parse($project->created_at)->translatedFormat('j F, Y')); ?>

													</td>
													<td>
													<?php echo e(\Carbon\Carbon::parse($project->updated_at)->translatedFormat('j F, Y')); ?>

													</td>
													<td>
													<?php echo e($project->repoLink); ?>

													</td>
													
													<td>
														<div class="card-body">
															<div class="avatar-group">
																<?php $__currentLoopData = $project->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<div class="avatar" style="a:hover { color: red; }" alt="<?php echo e($student->firstName); ?>">
																		<img class="avatar-img rounded-circle border border-white"  src="../assets_admin/img/profiles/avatar-02.jpg"/>
																		<div style="font-size: 7px;"><?php echo e($student->firstName); ?></div>
																	</div>																										
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</div>
												   		 </div>	
													</td>
													<td>
														<?php if($project->status == 'PENDING'): ?> <button type="button" class="btn btn-warning btn-sm">En instance</button> <?php endif; ?>
														<?php if($project->status == 'ACCEPTED'): ?> <button type="button" class="btn btn-success btn-sm">Validé</button> <?php endif; ?>
												
												 </td>
													<td  style="display: flex;">
														<?php if($project->status == 'PENDING'): ?><a href="<?php echo e(route('project-a-valide', $project->id)); ?>" class="btn btn-sm btn-success me-2"><i class="fa fa-check"></i></a>  <?php endif; ?>
														<form action="<?php echo e(route('project-a-supprimer')); ?>" method="POST">	
															<?php echo csrf_field(); ?>
														
														<input type="hidden" name="projectId" id="projectId" value='<?php echo e($project->id); ?>'>
														<button type="submit"  class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i>
														</form>
													</td>
												</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
								<div role="tabpanel" id="tab-5" class="tab-pane fade">
									<div class="table-responsive">
										<table class="table table-center table-hover mb-0 datatable">
											<thead>
												<tr>
													<th>Titre</th>	
													<th>Date de création</th>	
													<th>Date de Modification</th>	
													<th>GitHub</th>	
													<th>Collaborateurs</th>	
													<th>Status</th>	
													<th class="text-end">Actions</th>
												</tr>
											</thead>
											<tbody>
											<?php $__currentLoopData = $instructor->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($project->status == 'ACCEPTED'): ?> 
												<tr>
													
													<!-- <td>
														<h2 class="table-avatar">
															<a href="profile"><img class="me-2" src="../assets_admin/img/company/img-1.png" alt="User Image"></a>
														</h2>
													</td> -->
													
													<td><?php echo e(\Illuminate\Support\Str::limit($project->name , 15, $end='...')); ?></td>
													<td>
													<?php echo e(\Carbon\Carbon::parse($project->created_at)->translatedFormat('j F, Y')); ?>

													</td>
													<td>
													<?php echo e(\Carbon\Carbon::parse($project->updated_at)->translatedFormat('j F, Y')); ?>

													</td>
													<td>
													<?php echo e($project->repoLink); ?>

													</td>
													
													<td>
														<div class="card-body">
															<div class="avatar-group">
																<?php $__currentLoopData = $project->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<div class="avatar" style="a:hover { color: red; }" alt="<?php echo e($student->firstName); ?>">
																		<img class="avatar-img rounded-circle border border-white"  src="../assets_admin/img/profiles/avatar-02.jpg"/>
																		<div style="font-size: 9px;"><?php echo e($student->firstName); ?></div>
																	</div>																										
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</div>
												   		 </div>	
													</td>
													<td>
														<?php if($project->status == 'PENDING'): ?> <button type="button" class="btn btn-warning btn-sm">En instance</button> <?php endif; ?>
														<?php if($project->status == 'ACCEPTED'): ?> <button type="button" class="btn btn-success btn-sm">Validé</button> <?php endif; ?>
												
												 </td>
												 <td  style="display: flex;">
														<?php if($project->status == 'PENDING'): ?><a href="<?php echo e(route('project-a-valide', $project->id)); ?>" class="btn btn-sm btn-success me-2"><i class="fa fa-check"></i></a>  <?php endif; ?>
														<form action="<?php echo e(route('project-a-supprimer', $project->id)); ?>" method="POST">	
															<?php echo csrf_field(); ?>
														
														<button type="submit"  class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i>
														</form>
													</td>
												</tr>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
								<div role="tabpanel" id="tab-6" class="tab-pane fade">
									<div class="table-responsive">
										<table class="table table-center table-hover mb-0 datatable">
											<thead>
												<tr>
													
													<!-- <th>Avatar</th> -->
													<th>Titre</th>	
													<th>Date de création</th>	
													<th>Date de Modification</th>	
													<th>GitHub</th>	
													<th>Collaborateurs</th>	
													<th>Status</th>		
													<th class="text-end">Actions</th>
												</tr>
											</thead>
											<tbody>
											<?php $__currentLoopData = $instructor->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($project->status == 'PENDING'): ?> 	
											<tr>
													
													<!-- <td>
														<h2 class="table-avatar">
															<a href="profile"><img class="me-2" src="../assets_admin/img/company/img-1.png" alt="User Image"></a>
														</h2>
													</td> -->
													
													<td><?php echo e(\Illuminate\Support\Str::limit($project->name , 15, $end='...')); ?></td>
													<td>
													<?php echo e(\Carbon\Carbon::parse($project->created_at)->translatedFormat('j F, Y')); ?>

													</td>
													<td>
													<?php echo e(\Carbon\Carbon::parse($project->updated_at)->translatedFormat('j F, Y')); ?>

													</td>
													<td>
													<?php echo e($project->repoLink); ?>

													</td>
													
													<td>
														<div class="card-body">
															<div class="avatar-group">
																<?php $__currentLoopData = $project->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<div class="avatar" style="a:hover { color: red; }" alt="<?php echo e($student->firstName); ?>">
																		<img class="avatar-img rounded-circle border border-white"  src="../assets_admin/img/profiles/avatar-02.jpg"/>
																		<div style="font-size: 9px;"><?php echo e($student->firstName); ?></div>
																	</div>																										
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</div>
												   		 </div>	
													</td>
													<td>
														<?php if($project->status == 'PENDING'): ?> <button type="button" class="btn btn-warning btn-sm">En instance</button> <?php endif; ?>
														<?php if($project->status == 'ACCEPTED'): ?> <button type="button" class="btn btn-success btn-sm">Validé</button> <?php endif; ?>
												
												 </td>
													
												 <td  style="display: flex;">
														<?php if($project->status == 'PENDING'): ?><a href="<?php echo e(route('project-a-valide', $project->id)); ?>" class="btn btn-sm btn-success me-2"><i class="fa fa-check"></i></a>  <?php endif; ?>
														<form action="<?php echo e(route('project-a-supprimer', $project->id)); ?>" method="POST">	
															<?php echo csrf_field(); ?>
														
														<button type="submit"  class="btn btn-sm btn-danger"><i class="far fa-trash-alt"></i>
														</form>
														</td>
												</tr>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
								
							</div>
						</div>
					</div>
								
			</div>
			<!-- /Page Wrapper -->
		</div>
    </div>
<!-- /Main Wrapper -->
	<!-- Category Modal -->
		<div class="modal fade custom-modal" id="add-category">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">

				<div class="modal-header">
					<h4 class="modal-title">Projects</h4>
					<button type="button" class="close" data-bs-dismiss="modal"><span>&times;</span></button>
				</div>

				<div class="modal-body">
					<form>
						<div class="form-group">
							<label>Title</label>
							<input type="text" class="form-control" value="Website Designer Required For Directory Theme">
						</div>
						<div class="form-group">
							<label>Budget</label>
							<input type="text" class="form-control" value="$2222">
						</div>	
						<div class="form-group">
							<label>Technology</label>
							<input type="text" class="form-control" value="Angler">
						</div>		
						<div class="form-group">
							<label>Technology</label>
							<input type="text" class="form-control" value="AMAZE TECH">
						</div>
						<div class="form-group">
							<label>From Date</label>
							<div class="cal-icon">
								<input class="form-control datetimepicker" type="text"  value="20-01-2022">
							</div>
						</div>
						<div class="form-group">
							<label>To Date</label>
							<div class="cal-icon">
								<input class="form-control datetimepicker" type="text"  value="20-02-2022">
							</div>
						</div>				
						<div class="mt-4">
							<button type="submit" class="btn btn-primary btn-block">Submit</button>
						</div>
					</form>
				</div>
				</div>
			</div>
		</div>
		<!-- Category Modal -->

		<!-- Delete Modal -->
		<div class="modal custom-modal fade" id="delete_category" role="dialog">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-body">
						<div class="form-header">
							<h3>Supprimer</h3>
							<p>êtes vous sûr?</p>
						</div>
						<div class="modal-btn delete-action">
							<div class="row">
								<div class="col-6">
									<form action="<?php echo e(route('project-a-supprimer', $project->id)); ?>" method="POST">	
										<?php echo csrf_field(); ?>
									<a href="<?php echo e(route('project-a-supprimer', $project->id)); ?>" class="btn btn-primary continue-btn">Delete</a>
									<button type="submit" class="btn btn-primary continue-btn">Supprimer</button>
									</form>
								</div>
								<div class="col-6">
									<a href="javascript:void(0);" data-bs-dismiss="modal" class="btn btn-primary cancel-btn" style="color: black">Annuler</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Delete Modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\YcodeWork\app\resources\views/admin/projects.blade.php ENDPATH**/ ?>