<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/pages/auth.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php
        $sections = [
            [
                "link" => route('login-staff'),
                "label"=> "Staff"
    ],
    [
                "link" => route('loginR'),
                "label"=> "Recruteur"
    ],
    [
                "link" => route('login-student'),
                "label"=> "Apprenant"
    ]
]
    ?>
    <div class="auth">
        <div class="logo">
            <img src="<?php echo e(@asset("/assets/logo-dark.svg")); ?>" alt="logo">
        </div>
        <div class="sections">
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section" style="flex-basis: <?php echo e(100 / count($sections)); ?>%">
                    <a href="<?php echo e($section['link']); ?>"><span class="prefix">Login</span> <?php echo e($section['label']); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\Admin\Desktop\YcodeWork\app\resources\views/auth/auth.blade.php ENDPATH**/ ?>