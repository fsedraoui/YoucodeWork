		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>Kofejob - Bootstrap Admin HTML Template</title>
		
		<!-- Favicon -->
		  <link rel="shortcut icon" href="<?php echo e(asset('assets_admin/img/favicon.png')); ?>">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/css/bootstrap.min.css')); ?>">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/plugins/fontawesome/css/fontawesome.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/plugins/fontawesome/css/all.min.css')); ?>">

		<!-- Feather CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/css/feather.css')); ?>">

		<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/plugins/select2/css/select2.min.css')); ?>">
		
		<!-- Datatables CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/plugins/datatables/datatables.min.css')); ?>">

		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/css/bootstrap-datetimepicker.min.css')); ?>">
		
		<!-- Ck Editor -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/css/ckeditor.css')); ?>">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets_admin/css/style.css')); ?>"><?php /**PATH C:\Users\Admin\Desktop\YcodeWork\app\resources\views/layout/partials/head_admin.blade.php ENDPATH**/ ?>