<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProjectStudentController extends Controller
{
    //
}
